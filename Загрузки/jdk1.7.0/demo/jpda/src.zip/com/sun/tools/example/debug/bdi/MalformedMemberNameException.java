/*
 * Copyright (c) 1999, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.bdi;

class MalformedMemberNameException extends Exception {

    private static final long serialVersionUID = -7726664097374844485L;

    public MalformedMemberNameException() {
        super();
    }

    public MalformedMemberNameException(String s) {
        super(s);
    }
}
