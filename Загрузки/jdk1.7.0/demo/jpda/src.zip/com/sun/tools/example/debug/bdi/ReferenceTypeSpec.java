/*
 * Copyright (c) 1999, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.bdi;

import com.sun.jdi.*;

interface ReferenceTypeSpec {
    /**
     * Does the specified ReferenceType match this spec.
     */
    boolean matches(ReferenceType refType);

    @Override
    int hashCode();

    @Override
    boolean equals(Object obj);
}
