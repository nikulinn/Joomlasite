/*
 * Copyright (c) 1998, 1999, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

package com.sun.tools.example.debug.tty;

class MalformedMemberNameException extends Exception {
    private static final long serialVersionUID = 7759071468833196630L;

    public MalformedMemberNameException() {
        super();
    }

    public MalformedMemberNameException(String s) {
        super(s);
    }
}
